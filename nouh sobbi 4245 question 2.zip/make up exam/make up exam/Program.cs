﻿using System;
using System.Globalization;


namespace make_up_exam
{
    namespace make_up_exam
    {
        class Program
        {
            static void Main(string[] args)
            {
                string[] students = new string[10];
                int i;
                Console.WriteLine("Enter 10 Students presence with true/false");

                for (i = 0; i < 10; i++)
                {
                    Console.WriteLine($"Student {i + 1}: ");
                    students[i] = Console.ReadLine();
                }

                var count = CountStudents(students);
                Console.WriteLine("{0} are present", count[0]);
                Console.WriteLine("{0} are absent", count[1]);
                Console.WriteLine("{0} present is unknown", count[2]);
            }

            public static int[] CountStudents(string[] students)
            {
                int totalTrue = 0;
                int totalFalse = 0;
                int totalUnknown = 0;

                foreach (var student in students)
                {
                    if (student == "true")
                        totalTrue++;
                    else if (student == "false")
                        totalFalse++;
                    else
                        totalUnknown++;
                }

                int[] total = { totalTrue, totalFalse, totalUnknown };
                return total;
            }
        }
    }
}