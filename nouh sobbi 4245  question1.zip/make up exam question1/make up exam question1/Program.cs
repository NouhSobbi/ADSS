﻿using System;

namespace make_up_exam_question1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] students = new int[8];
            int i, mx, mn;
            int countOld = 0;
            int countYoung = 0;
            Console.WriteLine("Enter 8 ages of the students");
            mx = students[0];
            mn = 100;
            for (i = 0; i < 8; i++)
            {
                Console.WriteLine($"Student {i + 1}: ");
                students[i] = Convert.ToInt32(Console.ReadLine());
                if (students[i] > mx)
                {
                    mx = students[i];
                }

                if (students[i] < mn)
                {
                    mn = students[i];
                }
            }
            for (i = 0; i < 8; i++)
            {
                if (students[i] == mn)
                {
                    countYoung++;
                }
                if (students[i] == mx)
                {
                    countOld++;
                }
            }
            if (countOld > 1)
            {
                Console.WriteLine(" The amount of students with same old age are : {0}\n", countOld);
                Console.Write(" With age : {0}\n", mx);
            }
            else
            {
                Console.Write(" Oldest student is : {0}\n", mx);
            }

            if (countYoung > 1)
            {
                Console.WriteLine(" The amount of students with same young age are : {0}\n", countYoung);
                Console.Write(" With age : {0}\n", mn);
            }
            else
            {
                Console.Write("Youngest student is : {0}\n\n", mn);

            }

        }
    }
}
